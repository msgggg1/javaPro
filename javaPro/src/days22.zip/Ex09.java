package days22;

/**
 * @author msg
 * @date 2025. 3. 5. - 오후 4:06:07
 * @subject comparable 인터페이스 - 기본 정렬 기준을 구현하는데 사용. / 기본정렬기준은 있다.
 * @content	comparator 인터페이스 - 기본 정렬 기준 외에 다른 기준으로 사용. / 구현해서 사용
 */
public class Ex09 {

	public static void main(String[] args) {
		// Person 클래스 - Ex01
		

	} // main

} // class
